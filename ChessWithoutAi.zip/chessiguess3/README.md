# chessiguess
Recreated a chess game from scratch using PApplet processing on java. 
All classes made from scratch, except for the Game class using the basic PApplet template
Also created an AI chess bot(still in works) that plays for the opposite side of whichever you pick at the start of the game.
(currently no restart button but will add)


the one thing i learned. is that from making this whole thing from scratch is that. you're never done. i always have. at least one bug. or multiple that are just waiting for me
